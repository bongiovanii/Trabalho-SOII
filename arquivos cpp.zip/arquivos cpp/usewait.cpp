#include <iostream>
#include <unistd.h>
#include <sys/wait.h>

using namespace std;

int main() {
    // O ID retornado pelo fork() é zero quando o processo filho é criado
    pid_t pID = fork();
    pid_t cpid;

    if (pID == 0) {
        cout << "Saindo do processo filho." << endl;
        return 0;
    } else {
        cpid = wait(NULL);
    }

    cout << "PID do pai: " << getpid() << endl;
    cout << "PID do filho: " << cpid << endl;

    return 0;
}
