#include <stdio.h>

int main() {
    printf("Aied é 10, Aied é TOP, tá no Youtube");
}
