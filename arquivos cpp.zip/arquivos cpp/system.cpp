#include <iostream>

int main()
{
    system("ls -l");
    std::cout << "Executado" << std::endl;
    return 0;
}
