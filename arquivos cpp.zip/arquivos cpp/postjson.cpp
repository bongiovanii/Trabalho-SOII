#include <stdio.h>
#include <curl/curl.h>
#include <string>

int main(void) {
    CURLcode ret;
    CURL *hnd;
    struct curl_slist *slist1;

    std::string jsonstr = "{\"username\":\"aied\",\"password\":\"123456\"}"; // (p. 284, linha 10)

    slist1 = NULL;
    slist1 = curl_slist_append(slist1, "Content-Type: application/json"); // (p. 284, linha 13)

    hnd = curl_easy_init();

    curl_easy_setopt(hnd, CURLOPT_URL,
        "http://www.aied.com.br/linux/download/echo.php"); // (p. 284, linha 18)

    curl_easy_setopt(hnd, CURLOPT_POSTFIELDS, jsonstr.c_str());
    curl_easy_setopt(hnd, CURLOPT_USERAGENT, "curl/7.38.0");
    curl_easy_setopt(hnd, CURLOPT_HTTPHEADER, slist1);
    curl_easy_setopt(hnd, CURLOPT_CUSTOMREQUEST, "POST"); // (p. 285, linha 23)

    ret = curl_easy_perform(hnd);

    curl_easy_cleanup(hnd);
    hnd = NULL;

    curl_slist_free_all(slist1);
    slist1 = NULL;

    return 0;
}
