#include <netdb.h>
#include <arpa/inet.h>
#include <iostream>

int main() {
    struct hostent *he;
    char *ip;

    he = gethostbyname("www.aied.com.br"); // (p. 264, linha 9)

    if (he) {
        ip = inet_ntoa(*(struct in_addr*) he->h_addr_list[0]);
        std::cout << ip << std::endl;
    } else {
        std::cerr << "Erro ao resolver host." << std::endl;
    }

    return 0;
}
