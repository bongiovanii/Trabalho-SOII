#include <iostream>
#include <unistd.h>

using namespace std;

int variavelGlobal = 2;

int main() {
    string identidade;
    int variavelFuncao = 20;

    // O ID retornado pelo fork() é zero quando o processo filho é criado
    pid_t pID = fork();

    // Se é zero, então é um processo filho
    if (pID == 0) {
        identidade = "Processo filho: ";
        variavelGlobal++;
        variavelFuncao++;
    }
    // Se o pID retornado pelo fork for menor que zero, então houve falhas
    else if (pID < 0) {
        cerr << "Failed to fork" << endl;
        exit(1);
    }
    // Caso não seja nenhum dos dois, então é o processo pai
    else {
        identidade = "Processo pai:";
    }

    // Executado por ambos os processos
    cout << identidade;
    cout << " Variavel Global: " << variavelGlobal;
    cout << " Variável Funcao: " << variavelFuncao << endl;

    return 0;
}
