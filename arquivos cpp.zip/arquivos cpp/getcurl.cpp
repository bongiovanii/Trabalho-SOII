#include <stdio.h>
#include <curl/curl.h> // (p. 283, linha 2)

int main(void) {
    CURL *curl;
    FILE *fp;
    CURLcode res;
    char url[] =
    "http://www.aied.com.br/linux/download/output_image.iso"; // (p. 283, linha 8)
    char outfilename[FILENAME_MAX] = "/tmp/output_image.iso"; // (p. 283, linha 9)

    curl = curl_easy_init();
    if (curl) {
        fp = fopen(outfilename, "wb"); // (p. 284, linha 12)
        curl_easy_setopt(curl, CURLOPT_URL, url);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, NULL);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, fp);
        res = curl_easy_perform(curl);
        curl_easy_cleanup(curl);
        fclose(fp);

        if (res == CURLE_OK)
            printf("Download concluído com sucesso para /tmp/output_image.iso\n");
        else
            printf("Erro no download: %s\n", curl_easy_strerror(res));
    }

    return 0;
}
