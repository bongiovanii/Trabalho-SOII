#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h> // Para psignal

int main() {
    pid_t pid;
    int stat; // (p. 194, linha 11)

    pid = fork();

    if (pid == 0) {
        // Filho
        printf("Saindo do processo filho.\n");
        exit(1); // (p. 194, linha 15)
    }
    else if (pid > 0) {
        // Pai
        wait(&stat); // (p. 194, linha 17 - modificado do NULL)

        if (WIFEXITED(stat)) { // (p. 194, linha 20)
            printf("WEXIT: %d\n", WEXITSTATUS(stat)); // (p. 194, linha 21)
        }
        else if (WIFSIGNALED(stat)) {
            psignal(WTERMSIG(stat), "Sinal de saída: ");
        }

        printf("PID do pai: %d\n", getpid());
        printf("PID do filho: %d\n", pid);
    }

    return 0;
}
