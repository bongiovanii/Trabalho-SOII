#include <iostream>
#include <blkid/blkid.h>
#include <err.h>
#include <string>

int main(int argc, char *argv[]) {
    blkid_probe pr;
    const char *uuid;

    std::string partition = "/dev/sda1";

    pr = blkid_new_probe_from_filename(partition.c_str());
    if (!pr) {
        err(2, "Falha ao abrir %s", partition.c_str());
    }

    blkid_do_probe(pr);

    return 0;
}
