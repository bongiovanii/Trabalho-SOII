#include <stdio.h>
 #include "fibonacci.h" // Aspas "" para incluir um arquivo local
 int main(int argc, char* argv[]) {
 printf("F%d: %d \n", 4, fibonacci(4));
 return 0;
 
 }
