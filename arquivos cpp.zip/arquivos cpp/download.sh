#!/bin/bash
# (p. 285-286)
# Diretório de downloads do usuário atual
DOWNLOAD_DIR="/home/userlinux/Downloads"
URL_FILE="$DOWNLOAD_DIR/urls.txt"

# Cria o diretório se não existir
mkdir -p "$DOWNLOAD_DIR"

# Cria o arquivo urls.txt com a URL desejada
echo "http://www.aied.com.br/linux/download/output_image.iso" > "$URL_FILE"

# Entra no diretório de downloads
cd "$DOWNLOAD_DIR"

# Loop infinito
while true
do
    echo "Baixando arquivos listados em $URL_FILE..."

    xargs -n 1 curl -L -O \
        --output-dir "$DOWNLOAD_DIR" \
        -k --retry 9999999999999 --retry-max-time 0 -C - \
        < "$URL_FILE"

    echo "Aguardando 30 segundos..."
    sleep 30
done
